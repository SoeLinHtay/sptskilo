<div class="col-12 col-sm-10 vh-100 overflow-auto p-0 " id="section">
	<?php echo $__env->make('layouts.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class=" px-md-1">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
</div>
<?php /**PATH C:\Projects\Laravel\SPTS\resources\views\layouts\body.blade.php ENDPATH**/ ?>
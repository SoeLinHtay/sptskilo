<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- CSRF Token -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<title><?php echo e(config('app.name', 'Shwe Padauk Taxi Service')); ?></title>
	<link href="<?php echo e(asset('assets/icon/apple-touch-icon.png')); ?>" rel="apple-touch-icon" sizes="180x180">
	<link type="image/png" href="<?php echo e(asset('assets/icon/favicon-32x32.png')); ?>" rel="icon" sizes="32x32">
	<link type="image/png" href="<?php echo e(asset('assets/icon/favicon-16x16.png')); ?>" rel="icon" sizes="16x16">
	<link href="<?php echo e(asset('assets/icon/site.webmanifest')); ?>" rel="manifest">
	<!-- Fonts -->
	<link href="//fonts.gstatic.com" rel="dns-prefetch">
	<link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
	<!-- Scripts -->
	<link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
	<script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</head>

<body>
	<div id="app">
		<div class="row justify-content-center align-items-center vh-100 m-0">
			<div class="">
				<div class=" text-center w-100 d-none d-sm-block">
					<img src="<?php echo e(asset('assets/logo/logo.png')); ?>" alt="" width="15%" height="">
				</div>
				<div class=" text-center w-100 d-sm-none">
					<img src="<?php echo e(asset('assets/logo/logo.png')); ?>" alt="" width="50%" height="">
				</div>
				<div class="row justify-content-center">
					<div class="col-md-4">

						<form method="POST" action="<?php echo e(route('login')); ?>">
							<?php echo csrf_field(); ?>

							<div class="mb-2">
								<label class="col-md-6 col-form-label" for="email"><?php echo e(__('Email Address')); ?></label>
								<input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" type="email"
									value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Enter your email">

								<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>

							<div class="mb-2">
								<label class="col-md-6 col-form-label" for="password"><?php echo e(__('Password')); ?></label>

								<div class="input-group">
									<input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password"
										type="password" required autocomplete="current-password" placeholder="Enter your password">
									<button class="btn btn-secondary" id="show-hide" type="button" onclick="showPassword()">
										<i class="fa-solid fa-eye"></i>
									</button>
								</div>
								<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>

							<div class="row mb-0">
								<div class="col-mb-12 p-3">
									<button class="btn btn-primary form-control btn-lg" type="submit">
										<?php echo e(__('LOGIN')); ?>

									</button>
								</div>
							</div>
						</form>

					</div>
				</div>
			</div>

		</div>
		<div style="margin-top: -2rem">
			<p class="text-center small fw-bold">Copyright &copy; 2023 Shwe Padauk. All right reserved</p>
		</div>
	</div>
	<script>
		function showPassword() {
			const passwordInput = document.getElementById("password");
			const showHideButton = document.getElementById("show-hide");

			if (passwordInput.type === "password") {
				passwordInput.type = "text";
				showHideButton.innerHTML = '<i class="fa-solid fa-eye-slash"></i>';
			} else {
				passwordInput.type = "password";
				showHideButton.innerHTML = '<i class="fa-solid fa-eye"></i>';
			}
		}
	</script>
</body>

</html>
<?php /**PATH C:\Projects\Laravel\SPTS\resources\views\auth\login.blade.php ENDPATH**/ ?>
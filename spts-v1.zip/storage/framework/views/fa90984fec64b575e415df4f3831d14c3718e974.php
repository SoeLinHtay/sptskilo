<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row justify-content-between mb-2 px-5">
			<div class="col text-start <?php echo e($notificationsUnread>0?'text-danger':''); ?>">
				<span class="me-2">Unread</span> : <?php echo e($notificationsUnread); ?>

			</div>
			<div class="col text-end pe-5 me-5">
				<span class="me-5"><span class="me-2">Total</span> : <?php echo e($notificationsCount); ?></span>
			</div>
		</div>
		<div class="row px-5 m-0 pb-3">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex flex-row justify-content-between m-0 px-2">
                    <div class="col-md-11 row alert border <?php if($noti->status == 'unread'): ?> alert-primary <?php endif; ?> py-2 px-1 my-1 rounded justify-content-between text-center">
                        <div class="col">#<?php echo e($noti->user->driver_id); ?></div>
                        <div class="col text-start"><?php echo e($noti->user->name); ?></div>
                        <div class="col text-end"><?php echo e($noti->amount.' Ks'); ?></div>
                        <div class="col"><?php echo e($noti->service); ?></div>
                        <div class="col"><?php echo e(Carbon\Carbon::parse($noti->created_at)->diffForHumans()); ?></div>
                        <div class="col">
                            <!-- Modal -->
                            <div class="modal fade" id="topUpNotiModal<?php echo e($noti->id); ?>"
                                aria-labelledby="topUpNotiModal<?php echo e($noti->id); ?>Label" aria-hidden="true" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                                    <div class="modal-content">
                                        <div class="modal-header px-3 py-2">
                                            <h5 class="modal-title" id="topUpNotiModal<?php echo e($noti->id); ?>Label">TopUp Notification</h5>
                                            <button class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <ul class="list-group ">
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <h6 class=" text-muted">TopUp Username:</h6> <span class=""><?php echo e($noti->user->name); ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <h6 class=" text-muted">Service:</h6><span><?php echo e($noti->service); ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <h6 class=" text-muted">Account Username</h6><span><?php echo e($noti->account_name); ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <h6 class=" text-muted">Transfer Phone Number</h6><span><?php echo e($noti->phone); ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <h6 class=" text-muted">Amount</h6><span><?php echo e($noti->amount); ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-center">
                                                    <img class="img-fluid img-thumbnail rounded-top"
                                                        src="<?php echo e(asset('uploads/images/screenshots/' . $noti->screenshot)); ?>" alt="Top Up Screenshot"
                                                        width="100%">
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="modal-footer">
                                            <?php if($noti->status == 'unread'): ?>
                                                <button class="btn btn-dark" data-bs-dismiss="modal" type="button">Close</button>
                                                <form action="<?php echo e(route('topup.done', $noti)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-primary" type="submit">Done</button>
                                                </form>
                                            <?php else: ?>
                                                <button class="btn btn-dark" data-bs-dismiss="modal" type="button">Close</button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if($noti->status == 'unread'): ?>
                                <button class="btn btn-primary px-2 py-0" data-bs-toggle="modal"
                                    data-bs-target="#topUpNotiModal<?php echo e($noti->id); ?>" type="button">
                                    check
                                </button>
                            <?php else: ?>
                                <button class="btn btn-secondary px-2 py-0 " data-bs-toggle="modal"
                                    data-bs-target="#topUpNotiModal<?php echo e($noti->id); ?>" type="button">
                                    Done
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-1 py-2 my-1 text-center">
                        <form class="d-inline" action="<?php echo e(route('notifiaction.destroy', ['notifiaction' => $noti])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-reset btn-clear " type="submit">
                                <i class="fa-regular fa-trash-can text-danger"></i>
                            </button>
                        </form>
                    </div>
                </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
        <div class="row m-0 justify-content-between px-5 pb-3">
            <nav class="row m-0 py-2 px-5">
                <ul class="pagination pagination-sm justify-content-end p-0">
                    <li class="page-item <?php echo e($notifications->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" id="pre-page-link" href="<?php echo e($notifications->previousPageUrl()); ?>" rel="prev"><</a>
                    </li>

                    <?php if($notifications->lastPage() > 1 && $notifications->lastPage() < 10): ?>
                            <?php for($i = 1 ; $i <= $notifications->lastPage() ; $i++): ?>
                                <li class="page-item <?php echo e(($notifications->currentPage() == $i)? 'active':''); ?> ">
                                    <a class="page-link" id="next-page-link" href="<?php echo e($notifications->url($i)); ?>" rel="next"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>
                    <?php elseif($notifications->lastPage() >= 10): ?>
                            <?php for($i = 1 ; $i <= $notifications->lastPage() ; $i=$i+2): ?>
                                <li class="page-item <?php echo e(($notifications->currentPage() == $i)? 'active':''); ?> ">
                                    <a class="page-link" id="next-page-link" href="<?php echo e($notifications->url($i)); ?>" rel="next"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>
                    <?php endif; ?>

                    <li class="page-item <?php echo e($notifications->hasMorePages() ? '' : 'disabled'); ?>">
                        <a class="page-link" id="next-page-link" href="<?php echo e($notifications->nextPageUrl()); ?>" rel="next">></a>
                    </li>
                </ul>
            </nav>
        </div>

	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
	<script></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\transaction\notification.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
	<div class=" container-lg">
		<div class="row justify-content-center">
			<div class="col-lg-10 ">
				<div class="row justify-content-between">
					<div class="col-md-6 d-flex justify-content-start align-items-center">
						<button class="btn btn-primary" data-bs-toggle="collapse" href="#log_add" role="button" aria-expanded="false"
							aria-controls="log_add">Add Log</button>
					</div>
					<div class="col-md-6 d-flex justify-content-end align-items-center">
						<div class=" btn-group">
							<a class="btn btn-dark mb-3" href="<?php echo e($app_link); ?>">
								<small>Download App</small>
							</a>
							<a class="btn btn-outline-dark mb-3" data-bs-toggle="collapse" href="#app_link_update" role="button"
								aria-expanded="false" aria-controls="app_link_update" style="--bs-btn-border-width: 2px;"><i
									class="fa-solid fa-pen-to-square"></i></a>
						</div>
					</div>
				</div>
				<div class="row mb-3">
					<div class="collapse" id="app_link_update">
						<div class="card card-body">
							<form action="<?php echo e(route('appLink.update')); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<?php echo method_field('PUT'); ?>
								<div class="row justify-content-center align-items-center">
									<div class="col-10">
										<input class="form-control" name="app_link" type="text" aria-label="app_link" placeholder="app link...">
									</div>
									<div class="col-2">
										<button class=" btn btn-success">Update</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="row mb-3">
					<div class="collapse" id="log_add">
						<div class="card card-body">
							<form action="<?php echo e(route('changeLog.add')); ?>" method="POST">

								<?php echo csrf_field(); ?>

								<div class="row">
									<div class="col-8 mb-3">
										<textarea class="form-control" id="exampleFormControlTextarea1" name="changes" placeholder="changes..." rows="3"></textarea>
									</div>
									<div class="col-4 mb-3">
										<div class="col mb-2">
											<input class="form-control" name="version" type="text" placeholder="version">
										</div>
										<div class="col">
											<button class="form-control btn btn-primary" type="submit">Add</button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-10 table-responsive table-bordered">
				<table class="table align-middle text-center">
					<thead>
						<tr>
							<th scope="col">Version</th>
							<th scope="col">Changes</th>
							<th scope="col">Changed_at</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $changes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($change->version); ?></td>
								<td><?php echo e($change->changes); ?></td>
								<td><?php echo e($change->created_at); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	<?php $__env->stopSection(); ?>
	<?php $__env->startPush('script'); ?>
		<script></script>
	<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\changelog\index.blade.php ENDPATH**/ ?>
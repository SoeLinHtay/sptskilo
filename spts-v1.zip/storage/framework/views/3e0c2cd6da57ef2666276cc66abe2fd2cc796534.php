<?php $__env->startSection('content'); ?>
	<div class="container p-5">
		<div class="row justify-content-center align-items-stretch">
			<div class="col-lg-4 mb-3 ">
				<div class="card mb-3 h-100">
					<div class="card-body">
						<form method="POST" action="<?php echo e(route('notification.send')); ?>">
							<?php echo csrf_field(); ?>
							<div class="mb-2">
								<label class="col-md-6 col-form-label" for="title"><?php echo e(__('Notification Title')); ?></label>
								<input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title" type="title"
									required placeholder="Title">

								<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>

							<div class="mb-2">
								<label class="col-md-6 col-form-label" for="body"><?php echo e(__('Description')); ?></label>

								<div class="input-group">
									<textarea class="form-control <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" name="body" cols="30"
									 rows="10"></textarea>
								</div>
								<?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>

							<div class="row mb-0">
								<div class="col-mb-12 p-3 d-flex justify-content-end">
									<button class="btn btn-primary" type="submit">
										<i class="fa-solid fa-paper-plane me-2"></i><?php echo e(__('Send')); ?>

									</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="col-lg-8 ">
				<div class="card mb-3 h-100">
					<div class="card-body mb-3">
						<span class=""><i class="fa-solid fa-bell me-2"></i>Notifications History</span>
						<div class="table-responsive">
							<table class="table align-middle">
								<thead>
									<tr>
										<td>Title</td>
										<td>Description</td>
										<td>Date</td>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($noti->title); ?></td>
											<td><?php echo e($noti->body); ?></td>
											<td><?php echo e(Carbon\Carbon::parse($noti->created_at)->format('d-m-Y')); ?></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
					</div>
					<div class="card-body position-relative">
						<nav class="row m-0 position-absolute bottom-0 end-0 me-3">
							<ul class="pagination pagination-sm justify-content-end p-0 small">
								<li class="page-item <?php echo e($notifications->onFirstPage() ? 'disabled' : ''); ?>">
									<a class="page-link" href="<?php echo e($notifications->previousPageUrl()); ?>" rel="prev">&laquo;</a>
								</li>

								<li class="page-item active">
									<a class="page-link"
										href="<?php echo e($notifications->url($notifications->currentPage())); ?>"><?php echo e($notifications->currentPage()); ?></a>
								</li>

								<li class="page-item <?php echo e($notifications->hasMorePages() ? '' : 'disabled'); ?>">
									<a class="page-link" href="<?php echo e($notifications->nextPageUrl()); ?>" rel="next">&raquo;</a>
								</li>
							</ul>
						</nav>

					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\customNoti\index.blade.php ENDPATH**/ ?>
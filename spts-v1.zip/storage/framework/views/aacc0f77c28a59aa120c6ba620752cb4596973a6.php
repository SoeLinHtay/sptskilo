<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSRF Token -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<title><?php echo e(config('app.name', 'SPD Kilo Taxt')); ?></title>
	<link href="<?php echo e(asset('assets/icon/apple-touch-icon.png')); ?>" rel="apple-touch-icon" sizes="180x180">
	<link type="image/png" href="<?php echo e(asset('assets/icon/favicon-32x32.png')); ?>" rel="icon" sizes="32x32">
	<link type="image/png" href="<?php echo e(asset('assets/icon/favicon-16x16.png')); ?>" rel="icon" sizes="16x16">
	<link href="<?php echo e(asset('assets/icon/site.webmanifest')); ?>" rel="manifest">
	<style>
		#loader {
			background: rgb(255, 255, 255) url("https://admin.shwepadauktaxi.com/assets/loading/loading.gif") no-repeat center center !important;
			min-width: 100% !important;
			min-height: 100vh !important;
			position: fixed !important;
			z-index: 2000000 !important;
			scroll-behavior: none;
		}
	</style>
	<!-- Fonts -->
	<link href="//fonts.gstatic.com" rel="dns-prefetch">
	<link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

	<!-- Scripts -->
	<link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
	<script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</head>

<body>
	<div id="loader"></div>
	<div id="app">
		<div class="row m-0">
			<?php echo $__env->make('layouts.left-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('layouts.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
	<script>
		let loader = document.getElementById("loader");
		window.addEventListener("load", function() {
			loader.style.display = "none";
			window.scrollTo(0, 0);
		}, );
	</script>
	<?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH C:\Projects\Laravel\SPTS\resources\views\layouts\app.blade.php ENDPATH**/ ?>
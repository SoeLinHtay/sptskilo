<?php $__env->startSection('content'); ?>
	<div class=" container">
		<div class="row">
			<div class="col-md-3">
				<form action="<?php echo e(route('users.summary.search')); ?>" method="GET">
					<?php echo csrf_field(); ?>
					<div class="input-group mb-3">
						<button class="btn btn-outline-secondary text-dark" type="submit" style="border:1px solid #ced4da">
                            <i class="fa-solid fa-magnifying-glass">
							</i>
						</button>
						<input class="form-control" name="key" type="text" placeholder="Search">
					</div>
				</form>
			</div>
			<div class="col-md-9">
				<form action="<?php echo e(route('users.summary')); ?>" method="GET">
					<div class="row justify-content-end">
						<div class="col-md-3">
							<select class="form-select" id="type" name="type" aria-label="Default select example">
								<option value="most-balance" selected>Most Balance</option>
								<option value="least-balance">Least Balance</option>
								<option value="maximum-travel">Maximum Travel</option>
								<option value="minimum-travel">Minimum Travel</option>
							</select>
						</div>
						<div class="col-md-3">
							<select class="form-select" id="date" name="date" aria-label="Default select example">
								<option value="today">Today</option>
								<option value="start-10">start-10</option>
								<option value="10-20">10-20</option>
								<option value="20-end">20-end</option>
								<option value="this-month">This Month</option>
								<option value="this-year">This Year</option>
							</select>
						</div>
						<div class="col-md-1">
							<input class="btn btn-primary" type="submit" value="Sort">
						</div>
					</div>
				</form>
			</div>
		</div>
		<div class="table-responsive">
			<table class="table table-sm text-start">
				<thead class=" table-secondary" style="border-bottom:1px solid #ccc">
					<tr class="">
						<th>Driver ID</th>
						<th>Name</th>
						<th>Phone</th>
						<th>Trip</th>
						<th>Balence</th>
					</tr>
				</thead>
				<tbody class="table-group-divider" style="border-top:10px solid #ffffff">
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr <?php if($user->balance < 1000): ?> class="table-danger" <?php endif; ?>>
							<td><?php echo e($user->driver_id); ?></td>
							<td>
								<a class="text-dark text-decoration-none" href="<?php echo e(route('users.show', $user->id)); ?>"><?php echo e($user->name); ?></a>
							</td>
							<td><?php echo e($user->phone); ?></td>
							<td><?php echo e($user->total_trips); ?></td>
							<td><?php echo e($user->balance); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			<div class="row m-0 justify-content-between">
				<div class="col-md-2 ps-0">
					<p class=" text-muted">Total: <?php echo e($usersCount); ?></p>
				</div>
				<div class="col-md-2 pe-0">
					<nav class="row m-0">
						<ul class="pagination pagination-sm justify-content-end p-0">
							<li class="page-item <?php echo e($users->onFirstPage() ? 'disabled' : ''); ?>">
								<a class="page-link" id="pre-page-link" href="<?php echo e($users->previousPageUrl()); ?>" rel="prev"><i class="fa-solid fa-chevron-left"></i></a>
							</li>

							<?php if($users->lastPage() > 1): ?>
								<?php for($i = 1; $i <= $users->lastPage(); $i++): ?>
									<li class="page-item <?php echo e($users->currentPage() == $i ? 'active' : ''); ?> ">
										<a class="page-link" id="link_<?php echo e($i); ?>" href="<?php echo e($users->url($i)); ?>"
											rel="next"><?php echo e($i); ?></a>
									</li>
								<?php endfor; ?>
							<?php endif; ?>

							<li class="page-item <?php echo e($users->hasMorePages() ? '' : 'disabled'); ?>">
								<a class="page-link" id="next-page-link" href="<?php echo e($users->nextPageUrl()); ?>" rel="next"><i class="fa-solid fa-chevron-right"></i></a>
							</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
	<script>
		const searchParams = new URLSearchParams(window.location.search);

		const type = searchParams.get('type');
		const date = searchParams.get('date');
        const token = searchParams.get('_token');
        const key = searchParams.get('key');
		const typeElement = document.getElementById('type');
		const dateElement = document.getElementById('date');

		for (let i = 0; i < typeElement.options.length; i++) {
			const option = typeElement.options[i];
			if (option.value === type) {
				option.selected = true;
				break;
			}
		}

		for (let i = 0; i < dateElement.options.length; i++) {
			const option = dateElement.options[i];
			if (option.value === date) {
				option.selected = true;
				break;
			}
		}
		const pre_page_link = document.querySelector('#pre-page-link');
		const next_page_link = document.querySelector('#next-page-link');

		const lastPage = <?php echo e($users->lastPage()); ?>;
		const mid_links = [];
		for (let i = 1; i <= lastPage; i++) {
			mid_links.push(document.querySelector(`#link_${i}`))
		}
		const Links = [pre_page_link, next_page_link, ...mid_links];

		Links.forEach(link => {
			let href = link.getAttribute('href');
			if (href !== '' && type != null && date != null) {
				let url = new URL(href);
				let params = new URLSearchParams(url.search);

				params.append("type", type);
				params.append("date", date);

				url.search = params.toString();
				link.setAttribute('href', url.href);
			}
		});

        Links.forEach(link => {
			let href = link.getAttribute('href');
			if (href !== '' && key != null) {
				let url = new URL(href);
				let params = new URLSearchParams(url.search);

				params.append("_token", token);
				params.append("key", key);

				url.search = params.toString();
				link.setAttribute('href', url.href);
			}
		});
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\users\userSummary.blade.php ENDPATH**/ ?>
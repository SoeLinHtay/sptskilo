<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row justify-content-center">
			<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
				<div class="col-md-10 p-3 mb-2">
					<button class="btn btn-primary" id="fee-add-form-btn" type="button" onclick="showForm()">
						Add Fee
					</button>
				</div>
				<div class="col-md-10 p-3 mb-2 border d-none" id="fee-add-form">
					<form action="<?php echo e(route('fee.store')); ?>" method="post">
						<?php echo csrf_field(); ?>
						<div class="row">
							<div class=" col-md-5">
								<label for="fee-type">Fee Type</label>
								<input class="form-control <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fee-type" name="type" type="text"
									value="<?php echo e(old('type')); ?>" required autocomplete="type" autofocus>
								<?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="invalid-feedback">
										<?php echo e($message); ?>

									</div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class=" col-md-5">
								<label for="amount">Amount</label>
								<input class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="amount" name="amount" type="number"
									value="<?php echo e(old('amount')); ?>" required autocomplete="amount" autofocus>
								<?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="invalid-feedback">
										<?php echo e($message); ?>

									</div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="col-md-2 d-flex justify-content-around align-items-end p-3 p-md-0">
								<button class=" btn btn-primary " type="submit">
									<i class="fa-solid fa-check"></i>
								</button>
								<button class=" btn btn-dark " type="button" onclick="hideForm()">
									<i class="fa-solid fa-xmark"></i>
								</button>
							</div>
						</div>
					</form>
				</div>
			<?php endif; ?>
			<div class="col-md-10 table-responsive p-3">
				<table class="table table-striped">
					<thead>
						<tr class="">
							<th scope="col">Fee Type</th>
							<th scope="col">Amount</th>
							<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
								<th scope="col">Action</th>
							<?php endif; ?>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr id="fee-edit-tr<?php echo e($fee->id); ?>">
								<td scope="row"><?php echo e($fee->type); ?></td>
								<td><?php echo e($fee->amount); ?></td>
								<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
									<td>
										<span class="me-2">
											<button class=" btn-clear" onclick="show_edit_Form(<?php echo e($fee->id); ?>)">
												<span class="me-2">
													<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M7.33325 14H13.9999" stroke="#524E45" stroke-opacity="0.84" stroke-width="1.5"
															stroke-linecap="round" />
														<path fill-rule="evenodd" clip-rule="evenodd"
															d="M11.2563 3.21584C10.3437 2.41588 8.9494 2.4996 8.14147 3.40332C8.14147 3.40332 4.12591 7.89459 2.73345 9.45352C1.33917 11.0116 2.36121 13.164 2.36121 13.164C2.36121 13.164 4.66267 13.8857 6.03581 12.3495C7.40987 10.8132 11.4457 6.30012 11.4457 6.30012C12.2536 5.3964 12.1681 4.0158 11.2563 3.21584Z"
															stroke="#524E45" stroke-opacity="0.84" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
														<path d="M6.90698 4.86157L9.95038 7.5194" stroke="#524E45" stroke-opacity="0.84" stroke-width="1.5"
															stroke-linecap="round" stroke-linejoin="round" />
													</svg>
												</span>
											</button>
										</span>
										<span>
											<form class="d-inline" action="<?php echo e(route('fee.destroy', $fee)); ?>" method="POST">
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<button class="btn btn-reset btn-clear" type="submit">
													<i class="fa-regular fa-trash-can text-danger"></i>
												</button>
											</form>
										</span>
									</td>

								</tr>
								<tr class="d-none" id="fee-edit-form-<?php echo e($fee->id); ?>">
									<form action="<?php echo e(route('fee.update', $fee)); ?>" method="post">
										<?php echo csrf_field(); ?>
										<?php echo method_field('PUT'); ?>

										<td scope="row">
											<input class="form-control p-1 <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fee-type" name="type"
												type="text" value="<?php echo e(old('type', $fee->type)); ?>" required autocomplete="type" autofocus>
											<?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<div class="invalid-feedback">
													<?php echo e($message); ?>

												</div>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</td>
										<td>
											<input class="form-control p-1 <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="amount" name="amount"
												type="number" value="<?php echo e(old('amount', $fee->amount)); ?>" required autocomplete="amount" autofocus>
											<?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<div class="invalid-feedback">
													<?php echo e($message); ?>

												</div>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</td>
										<td>
											<span class="me-2">
												<button class="btn-clear border-0 pt-1" type="submit">
													<svg width="20" height="20" viewBox="0 0 17 17" fill="none"
														xmlns="http://www.w3.org/2000/svg">
														<path
															d="M15.0519 8.49999C15.0519 4.88137 12.1185 1.94791 8.49984 1.94791C4.88122 1.94791 1.94775 4.88137 1.94775 8.49999C1.94775 12.1186 4.88122 15.0521 8.49984 15.0521C12.1185 15.0521 15.0519 12.1186 15.0519 8.49999Z"
															stroke="#52CB08" stroke-opacity="0.73" stroke-width="1.5" />
														<path d="M6.375 8.50001L7.79167 9.91668L10.625 7.08334" stroke="#52CB08" stroke-opacity="0.73"
															stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
													</svg>
												</button>
											</span>
											<span class="">
												<button class=" btn-clear border-0 pt-1" type="button" onclick="hide_edit_Form(<?php echo e($fee->id); ?>)">
													<svg width="20" height="20" viewBox="0 0 17 17" fill="none"
														xmlns="http://www.w3.org/2000/svg">
														<path d="M9.91683 7.08334L7.0835 9.91668" stroke="#FF0606" stroke-opacity="0.55" stroke-width="1.5"
															stroke-linecap="round" />
														<path d="M9.91683 9.91668L7.0835 7.08334" stroke="#FF0606" stroke-opacity="0.55" stroke-width="1.5"
															stroke-linecap="round" />
														<path
															d="M15.0519 8.49999C15.0519 4.88137 12.1185 1.94791 8.49984 1.94791C4.88122 1.94791 1.94775 4.88137 1.94775 8.49999C1.94775 12.1186 4.88122 15.0521 8.49984 15.0521C12.1185 15.0521 15.0519 12.1186 15.0519 8.49999Z"
															stroke="#FF0606" stroke-opacity="0.55" stroke-width="1.5" />
													</svg>
												</button>
											</span>
										</td>

									</form>
								</tr>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
	<script>
		function showForm() {
			document.querySelector('#fee-add-form').classList.remove('d-none');
			document.querySelector('#fee-add-form-btn').classList.add('d-none');
		}

		function hideForm() {
			document.querySelector('#fee-add-form').classList.add('d-none');
			document.querySelector('#fee-add-form-btn').classList.remove('d-none');
		}

		function show_edit_Form(id) {
			document.querySelector('#fee-edit-form-' + id).classList.remove('d-none');
			document.querySelector('#fee-edit-tr' + id).classList.add('d-none');
		}

		function hide_edit_Form(id) {
			document.querySelector('#fee-edit-form-' + id).classList.add('d-none');
			document.querySelector('#fee-edit-tr' + id).classList.remove('d-none');
		}
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\fee\index.blade.php ENDPATH**/ ?>
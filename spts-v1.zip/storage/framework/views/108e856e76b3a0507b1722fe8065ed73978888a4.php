<?php $__env->startSection('content'); ?>
	<div class="container p-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<form method="POST" action="<?php echo e(route('admin.update', $user)); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class=" mb-3">
						<label class="form-label" for="name">
							<span class="text-danger">*</span><?php echo e(__('Username')); ?>

						</label>
						<input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" type="text"
							value="<?php echo e(old('name', $user->name)); ?>" required autocomplete="name" autofocus>
						<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								<?php echo e($message); ?>

							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class=" mb-3">
						<label class="form-label" for="email">
							<span class="text-danger">*</span><?php echo e(__('Email Address')); ?>

						</label>
						<input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" type="text"
							value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="email" autofocus>
						<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								<?php echo e($message); ?>

							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class=" mb-3">
						<label class="form-label" for="password"><span class="text-danger">*</span><?php echo e(__('Password')); ?></label>
						<input class="form-control" id="password" name="password" type="password">
						<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								<?php echo e($message); ?>

							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="mb-3">
						<label class="form-label" for="password-confirm"><span
								class="text-danger">*</span><?php echo e(__('Confirm Password')); ?></label>

						<input class="form-control" id="password-confirm" name="password_confirmation" type="password"
							autocomplete="new-password">
						<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="row justify-content-end">
						<div class="col-3 row m-0 pe-1">
							<button class="btn btn-primary " type="submit">Save</button>
						</div>
						<div class="col-3 row m-0 ps-1">
							<a class="btn btn-dark " href="<?php echo e(route('user.index')); ?>">Cancel</a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"
		integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ=="
		crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script>
		// Front NRC Image Preview
		$("#front_nrc").change(function() {
			var reader = new FileReader();
			reader.onload = function() {
				$("#front_nrc-preview").attr("src", reader.result).show();
				$("#front_nrc-cancel-btn").show();
			};
			reader.readAsDataURL(this.files[0]);
		});

		// Front NRC Image Cancel
		$("#front_nrc-cancel-btn").click(function() {
			$("#front_nrc").val("");
			$("#front_nrc-preview").hide();
			$("#front_nrc-cancel-btn").hide();
		});

		// Back NRC Image Preview
		$("#back_nrc").change(function() {
			var reader = new FileReader();
			reader.onload = function() {
				$("#back_nrc-preview").attr("src", reader.result).show();
				$("#back_nrc-cancel-btn").show();
			};
			reader.readAsDataURL(this.files[0]);
		});

		// Back NRC Image Cancel
		$("#back_nrc-cancel-btn").click(function() {
			$("#back_nrc").val("");
			$("#back_nrc-preview").hide();
			$("#back_nrc-cancel-btn").hide();
		});

		// Front Licence Image Preview
		$("#front_license").change(function() {
			var reader = new FileReader();
			reader.onload = function() {
				$("#front_license-preview").attr("src", reader.result).show();
				$("#front_license-cancel-btn").show();
			};
			reader.readAsDataURL(this.files[0]);
		});

		// Front Licence Image Cancel
		$("#front_license-cancel-btn").click(function() {
			$("#front_license").val("");
			$("#front_license-preview").hide();
			$("#front_license-cancel-btn").hide();
		});

		// Back Licence Image Preview
		$("#back_license").change(function() {
			var reader = new FileReader();
			reader.onload = function() {
				$("#back_license-preview").attr("src", reader.result).show();
				$("#back_license-cancel-btn").show();
			};
			reader.readAsDataURL(this.files[0]);
		});

		// Back Licence Image Cancel
		$("#back_license-cancel-btn").click(function() {
			$("#back_license").val("");
			$("#back_license-preview").hide();
			$("#back_license-cancel-btn").hide();
		});

		// profile Image Preview
		$("#profile_image").change(function() {
			const reader = new FileReader();
			reader.onload = function() {
				$("#profile_image-preview").attr("src", reader.result).show();
				$("#profile_image-cancel-btn").show();
			};
			reader.readAsDataURL(this.files[0]);
		})
		// profile Image Cancel
		$("#profile_image-cancel-btn").click(function() {
			$("#profile_image").val("");
			$("#profile_image-preview").hide();
			$("#profile_image-cancel-btn").hide();
		});

		$("#vehicle_image").change(function() {
			const reader = new FileReader();
			reader.onload = function() {
				$("#vehicle_image-preview").attr("src", reader.result).show();
				$("#vehicle_image-cancel-btn").show();
			};
			reader.readAsDataURL(this.files[0]);
		})
		// Vehicle Image Cancel
		$("#vehicle_image-cancel-btn").click(function() {
			$("#vehicle_image").val("");
			$("#vehicle_image-preview").hide();
			$("#vehicle_image-cancel-btn").hide();
		});
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\users\adminProfile.blade.php ENDPATH**/ ?>
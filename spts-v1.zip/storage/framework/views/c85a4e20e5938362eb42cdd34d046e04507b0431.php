<?php $__env->startSection('content'); ?>
	<div class="container p-5">
		<div class="row">
			<div class="col-md-12">
				<form method="POST" action="<?php echo e(route('users.update', $user)); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
					<div class="row mb-3">
						<div class="col-md-6">
							<div class=" mb-3">
								<label class="form-label" for="name">
									<span class="text-danger">*</span><?php echo e(__('Username')); ?>

								</label>
								<input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" type="text"
									value="<?php echo e(old('name', $user->name)); ?>" required autocomplete="name" autofocus>
								<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="invalid-feedback">
										<?php echo e($message); ?>

									</div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class=" mb-3">
								<label class="form-label" for="email">
									<span class="text-danger">*</span><?php echo e(__('Email Address')); ?>

								</label>
								<input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" type="text"
									value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="email" autofocus>
								<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="invalid-feedback">
										<?php echo e($message); ?>

									</div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class=" mb-3">
								<label class="form-label" for="phone">
									<span class="text-danger">*</span><?php echo e(__('Phone Number')); ?>

								</label>
								<input class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" name="phone" type="tel"
									value="<?php echo e(old('phone', $user->phone)); ?>" required autocomplete="phone" autofocus>
								<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="invalid-feedback">
										<?php echo e($message); ?>

									</div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="mb-3">
								<label class="form-label" for="birth_date"><span class="text-danger">*</span><?php echo e(__('Birth Date')); ?></label>
								<input class="form-control <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="birth_date" name="birth_date"
									type="date" value="<?php echo e(old('birth_date', Carbon\Carbon::parse($user->birth_date)->format('Y-m-d'))); ?>"
									autocomplete="birth_date">
								<?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="invalid-feedback">
										<?php echo e($message); ?>

									</div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>

						</div>
						<div class="col-md-6">
							<div class="row">
								<div class=" mb-3">
									<label class="form-label" for="driving_license">
										<span class="text-danger">*</span><?php echo e(__('Driving License')); ?>

									</label>
									<input class="form-control <?php $__errorArgs = ['driving_license'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="driving_license"
										name="driving_license" type="tel" value="<?php echo e(old('driving_license', $user->driving_license)); ?>" required
										autocomplete="driving_license" autofocus>
									<?php $__errorArgs = ['driving_license'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<div class="invalid-feedback">
											<?php echo e($message); ?>

										</div>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
								<div class=" mb-3">
									<label class="form-label" for="nrc_no">
										<span class="text-danger">*</span><?php echo e(__('NRC Number')); ?>

									</label>
									<input class="form-control <?php $__errorArgs = ['nrc_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nrc_no" name="nrc_no" type="tel"
										value="<?php echo e(old('nrc_no', $user->nrc_no)); ?>" required autocomplete="nrc_no" autofocus>
									<?php $__errorArgs = ['nrc_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<div class="invalid-feedback">
											<?php echo e($message); ?>

										</div>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
								<div class=" mb-3">
									<label class="form-label" for="password"><span class="text-danger">*</span><?php echo e(__('Password')); ?></label>
									<input class="form-control" id="password" name="password" type="password">
									<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<div class="invalid-feedback">
											<?php echo e($message); ?>

										</div>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
								<div class="mb-3">
									<label class="form-label" for="password-confirm"><span
											class="text-danger">*</span><?php echo e(__('Confirm Password')); ?></label>

									<input class="form-control" id="password-confirm" name="password_confirmation" type="password"
										autocomplete="new-password">
									<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<label class="form-label" for="address">
								<span class="text-danger">*</span><?php echo e(__('Address')); ?>

							</label>

							<textarea class=" form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address" name="address"
							 autocomplete="address"><?php echo e(old('address', $user->address)); ?></textarea>

							<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback">
									<?php echo e($message); ?>

								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
					<div class="row mb-3 align-items-end">
						<div class="col-md-6">
							<label class="form-label" for="vehicle_plate_no"><?php echo e(__('Vehicle Plate No')); ?></label>
							<input class="form-control <?php $__errorArgs = ['vehicle_plate_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="vehicle_plate_no"
								name="vehicle_plate_no" type="text"
								value="<?php echo e($user->vehicle ? old('vehicle_plate_no', $user->vehicle->vehicle_plate_no) : old('vehicle_plate_no')); ?>"
								autocomplete="vehicle_plate_no">
							<?php $__errorArgs = ['vehicle_plate_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback">
									<?php echo e($message); ?>

								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

						</div>
						<div class="col-md-6">
							<label class="form-label" for="vehicle_model"><?php echo e(__('Vehicle Model')); ?></label>
							<input class="form-control <?php $__errorArgs = ['vehicle_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="vehicle_model"
								name="vehicle_model" type="text"
								value="<?php echo e($user->vehicle ? old('old_vehicle_model', $user->vehicle->vehicle_model) : old('old_vehicle_model')); ?>"
								autocomplete="vehicle_model">
							<?php $__errorArgs = ['vehicle_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback">
									<?php echo e($message); ?>

								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>

						 <div class="col-md-6 ">
							<div class="row m-0 justify-content-center">
								<div class="mt-2 col-md-8" id="profile_image-preview-container">

									<?php if($user->userImage && $user->userImage->profile_image): ?>
										<img class="img-fluid rounded" id="profile_image-preview"
											src="<?php echo e(asset('uploads/images/profiles/' . $user->userImage->profile_image)); ?>" alt="Preview">
									<?php else: ?>
										<img class="img-fluid rounded" id="profile_image-preview" alt="Preview" style="display:none">
									<?php endif; ?>

								</div>
								<label class="form-label" for="profile_image"><?php echo e(__('Profile Photo')); ?></label>
								<div class="input-group p-0">

									<input class="form-control" id="profile_image" name="profile_image" type="file" accept="image/*">
									<button class="btn btn-danger" id="profile_image-cancel-btn" type="button"
										style="<?php if(!$user->userImage || !$user->userImage->profile_image): ?> <?php echo e('display:none'); ?> <?php endif; ?>">Cancel</button>

								</div>
								<?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						
					</div>
					
					<div class="row">
						<div class="col-md-1 row m-0 mb-3 pe-1">
							<button class="btn btn-primary " type="submit">Update</button>
						</div>
						<div class="col-md-1 row m-0 mb-3 pe-1">
							<a class="btn btn-dark " href="<?php echo e(route('user.index')); ?>">Cancel</a>
						</div>
					</div>
				</form>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"
		integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ=="
		crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script>

        // profile Image Preview
		$("#profile_image").change(function() {
			const reader = new FileReader();
			reader.onload = function() {
				$("#profile_image-preview").attr("src", reader.result).show();
				$("#profile_image-cancel-btn").show();
			};
			reader.readAsDataURL(this.files[0]);
		})

		// profile Image Cancel
		$("#profile_image-cancel-btn").click(function() {
			$("#profile_image").val("");
			$("#profile_image-preview").hide();
			$("#profile_image-cancel-btn").hide();
		});

		// Front NRC Image Preview
		// $("#front_nrc").change(function() {
		// 	var reader = new FileReader();
		// 	reader.onload = function() {
		// 		$("#front_nrc-preview").attr("src", reader.result).show();
		// 		$("#front_nrc-cancel-btn").show();
		// 	};
		// 	reader.readAsDataURL(this.files[0]);
		// });

		// // Front NRC Image Cancel
		// $("#front_nrc-cancel-btn").click(function() {
		// 	$("#front_nrc").val("");
		// 	$("#front_nrc-preview").hide();
		// 	$("#front_nrc-cancel-btn").hide();
		// });

		// // Back NRC Image Preview
		// $("#back_nrc").change(function() {
		// 	var reader = new FileReader();
		// 	reader.onload = function() {
		// 		$("#back_nrc-preview").attr("src", reader.result).show();
		// 		$("#back_nrc-cancel-btn").show();
		// 	};
		// 	reader.readAsDataURL(this.files[0]);
		// });

		// // Back NRC Image Cancel
		// $("#back_nrc-cancel-btn").click(function() {
		// 	$("#back_nrc").val("");
		// 	$("#back_nrc-preview").hide();
		// 	$("#back_nrc-cancel-btn").hide();
		// });

		// // Front Licence Image Preview
		// $("#front_license").change(function() {
		// 	var reader = new FileReader();
		// 	reader.onload = function() {
		// 		$("#front_license-preview").attr("src", reader.result).show();
		// 		$("#front_license-cancel-btn").show();
		// 	};
		// 	reader.readAsDataURL(this.files[0]);
		// });

		// // Front Licence Image Cancel
		// $("#front_license-cancel-btn").click(function() {
		// 	$("#front_license").val("");
		// 	$("#front_license-preview").hide();
		// 	$("#front_license-cancel-btn").hide();
		// });

		// // Back Licence Image Preview
		// $("#back_license").change(function() {
		// 	var reader = new FileReader();
		// 	reader.onload = function() {
		// 		$("#back_license-preview").attr("src", reader.result).show();
		// 		$("#back_license-cancel-btn").show();
		// 	};
		// 	reader.readAsDataURL(this.files[0]);
		// });

		// // Back Licence Image Cancel
		// $("#back_license-cancel-btn").click(function() {
		// 	$("#back_license").val("");
		// 	$("#back_license-preview").hide();
		// 	$("#back_license-cancel-btn").hide();
		// });

		// $("#vehicle_image").change(function() {
		// 	const reader = new FileReader();
		// 	reader.onload = function() {
		// 		$("#vehicle_image-preview").attr("src", reader.result).show();
		// 		$("#vehicle_image-cancel-btn").show();
		// 	};
		// 	reader.readAsDataURL(this.files[0]);
		// })
		// // Vehicle Image Cancel
		// $("#vehicle_image-cancel-btn").click(function() {
		// 	$("#vehicle_image").val("");
		// 	$("#vehicle_image-preview").hide();
		// 	$("#vehicle_image-cancel-btn").hide();
		// });
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\users\edit.blade.php ENDPATH**/ ?>
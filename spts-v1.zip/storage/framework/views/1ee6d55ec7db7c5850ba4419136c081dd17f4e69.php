<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="col-md-3">
			<form action="<?php echo e(route('users.search.active')); ?>" method="GET">
				<?php echo csrf_field(); ?>
				<div class="input-group mb-3">
					<button class="btn btn-outline-secondary text-dark" type="submit" style="border:1px solid #ced4da"><i
							class="fa-solid fa-magnifying-glass">
						</i>
					</button>
					<input class="form-control" name="key" type="text" placeholder="Search">
				</div>
			</form>
		</div>
		<div class="table-responsive small">
			<table class="table table-striped table-hover align-middle">
				<thead class=" table-secondary" style="border-bottom:1px solid #ccc">
					<tr class="">
						<th>No</th>
						<th>Driver ID</th>
						<th>Driver Name</th>
						<th>Vehicle number</th>
						<th>Phone number</th>
						<th>Address</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody class="table-group-divider" style="border-top:10px solid #ffffff">
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="">
							<td scope="row"><?php echo e($key + 1); ?></td>
							<td><?php echo e($user->driver_id); ?></td>
							<td>
								<a class="text-dark text-decoration-none" href="<?php echo e(route('users.show', $user->id)); ?>"><?php echo e($user->name); ?></a>
							</td>
							<td><?php echo e($user->vehicle ? $user->vehicle->vehicle_plate_no : ''); ?></td>
							<td><?php echo e($user->phone); ?></td>
							<td><?php echo e($user->address); ?></td>
							<td>
								<?php if($user->status == 'active'): ?>
									<span class="text-success">Active</span>
								<?php else: ?>
									<span class="text-danger">Pending</span>
								<?php endif; ?>
							</td>
							<td>
								<span>
									<form class="d-inline" action="<?php echo e(route('users.turn-pending', $user->id)); ?>" method="POST">
										<?php echo csrf_field(); ?>
										<?php echo method_field('PUT'); ?>
										<button class="btn btn-sm btn-danger p-1" type="submit">
											Pending
										</button>
									</form>
								</span>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</tbody>
			</table>
			<div class="row m-0 justify-content-between">
				<div class="col-md-2 ps-0">
					<p class=" text-muted">Total: <?php echo e($usersCount); ?></p>
				</div>
				<div class="col-md-2 pe-0">

					<nav class="row m-0">
						<ul class="pagination pagination-sm justify-content-end p-0">
							<li class="page-item <?php echo e($users->onFirstPage() ? 'disabled' : ''); ?>">
								<a class="page-link" id="pre-page-link" href="<?php echo e($users->previousPageUrl()); ?>" rel="prev"><</a>
							</li>

							<?php if($users->lastPage() > 1): ?>
                                    <?php for($i = 1 ; $i <= $users->lastPage() ; $i++): ?>
                                        <li class="page-item <?php echo e(($users->currentPage() == $i)? 'active':''); ?> ">
                                            <a class="page-link" id="next-page-link" href="<?php echo e($users->url($i)); ?>" rel="next"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>
                            <?php endif; ?>

							<li class="page-item <?php echo e($users->hasMorePages() ? '' : 'disabled'); ?>">
								<a class="page-link" id="next-page-link" href="<?php echo e($users->nextPageUrl()); ?>" rel="next">></a>
							</li>
						</ul>
					</nav>

				</div>
			</div>

		</div>

	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
	<script></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\users\activeUser.blade.php ENDPATH**/ ?>
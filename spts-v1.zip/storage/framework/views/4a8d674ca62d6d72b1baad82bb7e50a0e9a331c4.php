<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="col-md-3">
			<form action="<?php echo e(route('trips.search')); ?>" method="GET">
				<?php echo csrf_field(); ?>
				<div class="input-group mb-3">
					<button class="btn btn-outline-secondary text-dark" type="submit" style="border:1px solid #ced4da"><i
							class="fa-solid fa-magnifying-glass">
						</i>
					</button>
					<input class="form-control" name="key" type="text" placeholder="Search">
				</div>
			</form>
		</div>
		<div class="table-responsive small">
			<table class="table table-striped table-hover">
				<thead class="table-secondary align-top" style="border-bottom:1px solid #ccc">
					<tr class="">
						<th>Driver ID</th>
						<th>Driver Name</th>
						<th>Distance (Km)</th>
						<th>Duration</th>
						<th>Waiting Time</th>
						<th>Normal Cost (Ks)</th>
						<th>Waiting Cost (Ks)</th>
						<th>Extra Cost (Ks)</th>
						<th>Total Cost (Ks)</th>
						<th>Date</th>
						<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
							<th>Action</th>
						<?php endif; ?>
					</tr>
				</thead>
				<tbody class="table-group-divider" style="border-top:10px solid #ffffff">
					<?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="">
							<td scope="row"><?php echo e($trip->user->driver_id); ?></td>
							<td>
								<a class="text-dark text-decoration-none"
									href="<?php echo e(route('users.show', $trip->user->id)); ?>"><?php echo e($trip->user->name); ?></a>
							</td>
							<td><?php echo e($trip->distance); ?> </td>
							<td><?php echo e($trip->duration); ?> </td>
							<td><?php echo e($trip->waiting_time); ?></td>
							<td><?php echo e($trip->normal_fee); ?> </td>
							<td><?php echo e($trip->waiting_fee); ?> </td>
							<td><?php echo e($trip->extra_fee); ?> </td>
							<td><?php echo e($trip->total_cost); ?></td>
							<td><?php echo e(Carbon\Carbon::parse($trip->created_at)->format('d-m-Y')); ?></td>
							<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
								<td>
									<span>
										<form class="d-inline" action="<?php echo e(route('trip.destroy', ['trip' => $trip])); ?>" method="POST">
											<?php echo csrf_field(); ?>
											<?php echo method_field('DELETE'); ?>
											<button class="btn btn-reset btn-clear" type="submit">
												<i class="fa-regular fa-trash-can text-danger"></i>
											</button>
										</form>
									</span>
								</td>
							<?php endif; ?>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</tbody>
			</table>
			<div class="row m-0 justify-content-between">
				<div class="col-md-2 ps-0">
					<p class=" text-muted">Total: <?php echo e($tripsCount); ?></p>
				</div>

				<div class="col-md-2 pe-0">
					<nav class="row m-0">
						<ul class="pagination pagination-sm justify-content-end p-0">
							<li class="page-item <?php echo e($trips->onFirstPage() ? 'disabled' : ''); ?>">
								<a class="page-link" id="pre-page-link" href="<?php echo e($trips->previousPageUrl()); ?>" rel="prev"><</a>
							</li>


							<?php if($trips->lastPage() > 1 && $trips->lastPage() < 10): ?>
                                    <?php for($i = 1 ; $i <= $trips->lastPage() ; $i++): ?>
                                        <li class="page-item <?php echo e(($trips->currentPage() == $i)? 'active':''); ?> ">
                                            <a class="page-link" id="next-page-link" href="<?php echo e($trips->url($i)); ?>" rel="next"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>
                            <?php elseif($trips->lastPage() >= 10): ?>
                                    <?php for($i = 2 ; $i <= $trips->lastPage() ; $i=$i+2): ?>
                                        <li class="page-item <?php echo e(($trips->currentPage() == $i)? 'active':''); ?> ">
                                            <a class="page-link" id="next-page-link" href="<?php echo e($trips->url($i)); ?>" rel="next"><?php echo e($i); ?></a>
                                        </li>
                                        <?php if($trips->currentPage()%2 != 0 && $i < $trips->currentPage() && ($i+2) > $trips->currentPage() ): ?>
                                            <li class="page-item active ">
                                                <a class="page-link" id="next-page-link" href="<?php echo e($trips->url($trips->currentPage())); ?>" rel="next"><?php echo e($trips->currentPage()); ?></a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                            <?php endif; ?>

							<li class="page-item <?php echo e($trips->hasMorePages() ? '' : 'disabled'); ?>">
								<a class="page-link" id="next-page-link" href="<?php echo e($trips->nextPageUrl()); ?>" rel="next">></a>
							</li>
						</ul>
					</nav>
				</div>

			</div>

		</div>

	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
	<script></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\trip\index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
	<div class=" container">
		<div class="col-md-3">
			<form action="<?php echo e(route('topup.history.search')); ?>" method="GET">
				<?php echo csrf_field(); ?>
				<div class="input-group mb-3">
					<button class="btn btn-outline-light" type="submit" style="border:1px solid #ced4da"><i
							class="fa-solid fa-magnifying-glass">
						</i>
					</button>
					<input class="form-control" name="key" type="text" placeholder="Search">
				</div>
			</form>
		</div>
		<div class="table-responsive">
			<table class="table table-striped table-hover align-middle">
				<thead class=" table-secondary" style="border-bottom:1px solid #ccc">
					<tr class="">
						<th>No</th>
						<th>Driver Name</th>
						<th>Vehicle number</th>
						<th>Phone number</th>
						<th>Top UP</th>
					</tr>
				</thead>
				<tbody class="table-group-divider" style="border-top:10px solid #ffffff">
					<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="">
							<td scope="row"><?php echo e($transaction->user->driver_id); ?></td>
							<td><?php echo e($transaction->user->name); ?></td>
							<td><?php echo e($transaction->user->vehicle ? $transaction->user->vehicle->vehicle_plate_no : ''); ?></td>
							<td><?php echo e($transaction->user->phone); ?></td>
							<td><?php echo e($transaction->amount); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</tbody>
			</table>
			<div class="row m-0 justify-content-between">
				<div class="col-md-2 ps-0">
					<p class=" text-muted">Total: <?php echo e($transactionCount); ?></p>
				</div>

				<div class="col-md-2 pe-0">
					<nav class="row m-0">
						<ul class="pagination pagination-sm justify-content-end p-0">
							<li class="page-item <?php echo e($transactions->onFirstPage() ? 'disabled' : ''); ?>">
								<a class="page-link" id="pre-page-link" href="<?php echo e($transactions->previousPageUrl()); ?>" rel="prev"><</a>
							</li>

							<?php if($transactions->lastPage() > 1): ?>
                                    <?php for($i = 1 ; $i <= $transactions->lastPage() ; $i++): ?>
                                        <li class="page-item <?php echo e(($transactions->currentPage() == $i)? 'active':''); ?> ">
                                            <a class="page-link" id="next-page-link" href="<?php echo e($transactions->url($i)); ?>" rel="next"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>
                            <?php endif; ?>

							<li class="page-item <?php echo e($transactions->hasMorePages() ? '' : 'disabled'); ?>">
								<a class="page-link" id="next-page-link" href="<?php echo e($transactions->nextPageUrl()); ?>" rel="next">></a>
							</li>
						</ul>
					</nav>
				</div>
			</div>

		</div>

	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
	<script></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\SPTS\resources\views\backend\transaction\history.blade.php ENDPATH**/ ?>
<div class="col-12 col-sm-10 vh-100 overflow-auto p-0 " id="section">
	@include('layouts.top-nav')
	<div class=" px-md-1">
		@yield('content')
	</div>
</div>
